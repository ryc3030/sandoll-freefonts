# free-korean-fonts-ppt

피피티를 분석해 어울리는 무료 한글 폰트를 고르고 적용하는 Agent Skill입니다.
원본·최신판: https://github.com/ryc3030/sandoll-freefonts

## 설치
- Claude(claude.ai·데스크톱): 설정 → 기능(Capabilities) → 스킬에서 이 ZIP 업로드
- Claude Code: `~/.claude/skills/`에 압축을 풀기
- OpenAI Codex: 프로젝트의 `.agents/skills/`(또는 `.codex/skills/`)에 압축을 풀기
- Gemini CLI: `gemini skills install <압축 푼 폴더>` 또는 `~/.gemini/skills/`에 압축을 풀기
- ChatGPT(스킬 지원 요금제·데스크톱 앱): 스킬 메뉴에서 폴더/SKILL.md를 가져오기
- Gemini 앱(Gem)·스킬이 없는 챗봇: SKILL.md 내용을 Gem·프로젝트 지침에 붙여 넣고, 이 ZIP을 대화에 올려 쓰기
